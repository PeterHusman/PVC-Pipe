namespace PVCPipeLibrary
{
    public partial class PVCServerInterface
    {
        public enum RegisterResult
        {
            Success,
            Failure
        }
    }
}
