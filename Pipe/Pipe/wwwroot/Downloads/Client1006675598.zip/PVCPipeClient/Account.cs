namespace PVCPipeLibrary
{
    public class Account
    {
        public string Username;
        public string Password;
        public Account(string username, string password)
        {
            Username = username;
            Password = password;
        }
    }
}
