using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using McMaster.Extensions.CommandLineUtils;
using PVCPipeLibrary;

namespace PVCCommandLine
{
    [Command("pvc")]
    [Subcommand("commit", typeof(CommitCommand))]
    class PVC : PVCCommandBase
    {
        static void Main(string[] args)
        {
            
            CommandLineApplication.ExecuteAsync<PVC>(args);
            Console.ReadKey();
        }

        //https://github.com/natemcmaster/CommandLineUtils/blob/master/docs/samples/subcommands/inheritance/Program.cs
        //CredentialCache
        //NetworkCredential

        public NetworkCredential GetCredential()
        {
            CredentialCache cache = new CredentialCache();
            Credential = cache.GetCredential(new Uri("http://pvc-pipe.com"), "");
            return Credential;
        }

        public NetworkCredential SetCredential(string username, string password)
        {
            CredentialCache cache = new CredentialCache();
            NetworkCredential cred = new NetworkCredential(username, password);
            Credential = cred;
            cache.Add(new Uri("http://pvc-pipe.com"), "", cred);
            return Credential;
        }

        [Option("--dir=<path>")]
        [DirectoryExists]
        public string PVCDir { get; set; }

        //public string Command { get; set; }

        public NetworkCredential Credential;

        public async Task OnExecuteAsync(CommandLineApplication app)
        {
            app.ShowHelp();
            return;
        }

        public override List<string> CreateArgs()
        {
            List<string> args = new List<string>();
            if (PVCDir != null)
            {
                args.Add("--dir=" + PVCDir);
            }
            return args;
        }
    }

    [Command(Description = "Sign in. Only authenticates when a command which requires an account is run")]
    class LogInCommand : PVCCommandBase
    {
        private PVC Parent { get; set; }

        public override List<string> CreateArgs()
        {
            List<string> args = Parent.CreateArgs();
            args.Add("login");
            return args;
        }
    }

    [Command(Description = "Commit changes to a repository")]
    class CommitCommand : PVCCommandBase
    {

        [Option("-m")]
        public string Message { get; set; }

        [Option("-a")]
        public string Author { get; set; }

        private PVC Parent { get; set; }

        public override List<string> CreateArgs()
        {
            List<string> args = Parent.CreateArgs();
            args.Add("commit");
            if(Message != null)
            {
                args.Add("-m");
                args.Add(Message);
            }
            if(Author != null)
            {
                args.Add("-a");
                args.Add(Author);
            }
            return args;
        }

        public async Task OnExecuteAsync(CommandLineApplication app)
        {
            PVCServerInterface interf = new PVCServerInterface(string.IsNullOrEmpty(Parent.PVCDir) ? Directory.GetCurrentDirectory() : Parent.PVCDir);
            var message = app.Option("-m <MESSAGE>", "The message", CommandOptionType.SingleValue);
            var author = app.Option("-a <AUTHOR>", "The author", CommandOptionType.SingleValue);
            Parent.GetCredential();
            if(string.IsNullOrEmpty(Message))
            {
                Console.WriteLine("A commit must have a message.");
                return;
            }
            if (string.IsNullOrEmpty(Author))
            {
                if (Parent.Credential == null)
                {
                    Console.WriteLine("A commit must have an author. This can be specified either by using the -a option or by logging in.");
                    return;
                }
                Author = Parent.Credential.UserName;
            }
            await interf.Commit(Message, Author, Author, DateTime.Now);
        }
    }

    [HelpOption("--help")]
    abstract class PVCCommandBase
    {
        public abstract List<string> CreateArgs();

        protected virtual async Task<int> OnExecuteAsync(CommandLineApplication app)
        {
            var args = CreateArgs();

            Console.WriteLine("Result = pvc " + ArgumentEscaper.EscapeAndConcatenate(args));
            return 0;
        }
    }
}
